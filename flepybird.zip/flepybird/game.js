const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Postavljanje veličine platna u odnosu na veličinu ekrana
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Funkcija koja ažurira veličinu platna kada se promeni veličina ekrana
window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    // Možda će biti potrebno ponovo nacrtati pticu i prepreke ovde
});

// Promenljive za pticu (kocka)
let bird = {
    x: 50,
    y: 150,
    width: 20,
    height: 20,
    gravity: 0.6,
    lift: -12,
    velocity: 0
};

// Promenljive za prepreke (stubovi)
let pipes = [];
let pipeWidth = 40;
let pipeGap = 120;
let pipeSpeed = 2;
let frameCount = 0;

// Početni rezultati
let score = 0;
let gameOver = false;

// Kontrola letenja ptice (tastatura)
document.addEventListener('keydown', () => {
    bird.velocity = bird.lift;
});

// Kontrola letenja ptice (touch ekran)
document.addEventListener('touchstart', () => {
    bird.velocity = bird.lift;
});

// Kontrola letenja ptice (desni klik miša)
document.addEventListener('contextmenu', (event) => {
    event.preventDefault(); // Spreči otvaranje kontekstualnog menija
    bird.velocity = bird.lift;
});


// Funkcija za ažuriranje ptice
function updateBird() {
    bird.velocity += bird.gravity;
    bird.y += bird.velocity;

    if (bird.y > canvas.height - bird.height) {
        bird.y = canvas.height - bird.height;
        bird.velocity = 0;
        endGame();
    }

    if (bird.y < 0) {
        bird.y = 0;
        bird.velocity = 0;
        endGame();
    }
}

// Funkcija za kreiranje prepreka
function createPipe() {
    let pipeY = Math.random() * (canvas.height - pipeGap);
    pipes.push({
        x: canvas.width,
        y: pipeY,
        width: pipeWidth,
        gap: pipeGap
    });
}

// Funkcija za ažuriranje prepreka
function updatePipes() {
    for (let i = pipes.length - 1; i >= 0; i--) {
        pipes[i].x -= pipeSpeed;

        // Provera sudara sa pticom
        if (
            bird.x < pipes[i].x + pipeWidth &&
            bird.x + bird.width > pipes[i].x &&
            (bird.y < pipes[i].y || bird.y + bird.height > pipes[i].y + pipeGap)
        ) {
            endGame();
        }

        // Uklanjanje prepreka kad prođu ekran
        if (pipes[i].x + pipeWidth < 0) {
            pipes.splice(i, 1);
            score++;
        }
    }
}

// Funkcija za crtanje prepreka
function drawPipes() {
    ctx.fillStyle = 'green';
    pipes.forEach(pipe => {
        ctx.fillRect(pipe.x, 0, pipe.width, pipe.y); // Gornja cev
        ctx.fillRect(pipe.x, pipe.y + pipe.gap, pipe.width, canvas.height - (pipe.y + pipe.gap)); // Donja cev
    });
}

// Funkcija za crtanje ptice
function drawBird() {
    ctx.fillStyle = 'yellow';
    ctx.fillRect(bird.x, bird.y, bird.width, bird.height);
}

// Funkcija za kraj igre
function endGame() {
    gameOver = true;
    alert('Game Over! Your score: ' + score);
    document.location.reload();
}

// Funkcija za crtanje rezultata
function drawScore() {
    ctx.fillStyle = 'black';
    ctx.font = '20px Arial';
    ctx.fillText('Score: ' + score, 10, 25);
}

// Glavna funkcija igre
function gameLoop() {
    if (!gameOver) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        updateBird();
        updatePipes();

        drawBird();
        drawPipes();
        drawScore();

        // Kreiraj nove prepreke svakih 90 frejmova
        if (frameCount % 90 === 0) {
            createPipe();
        }

        frameCount++;
        requestAnimationFrame(gameLoop);
    }
}

// Početak igre
gameLoop();
